# [SDF04] Challenge: HTML Responsive Footer 🖼️

Welcome to your **HTML and CSS challenge!** This project is focused on applying all you've learned to design a fully responsive website footer.  


## 📖 Challenge Brief  

All project instructions, requirements, and submission details can be found in the **challenge brief**.  
Make sure to read it carefully before you start:  

🔗 You will find the Challenge Brief in this repo in a markdown file called `CHALLENGE-BRIEF.MD`