# [SDF05] Responsive Tailwind Footer Refactor 🦶

Welcome to your **Tailwind Refactor Challenge!** This project is focused on applying Tailwind’s **utility-first approach** to design a fully responsive website footer.  


## 📖 Challenge Brief  

All project instructions, requirements, and submission details can be found in the **challenge brief**.  
Make sure to read it carefully before you start:  

🔗 You will find the Challenge Brief in this repo in a markdown file called `CHALLENGE-BRIEF.MD`